package com.example.demo.model;


import com.example.demo.service.FuncionarioService;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Funcionario extends Pessoa  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String cargo;
    private boolean ativo;

    private String dataAdmissao;

    private int horasDebito;
    private int cargaHoraria;
    private int horasTrabalhadas;

    @ManyToOne
    @JoinColumn(name = "departamento_id")
    private Departamento departamento;

    @NotNull
    @Column(nullable = false)
    @Min(value = 1)
    private double salario;
    
    public Funcionario() {
    }
 
    public Funcionario(String nome, String cargo, String cpf, String idade, boolean ativo, double salario) {
        super(nome, cpf, idade);
        this.salario = salario;
    }

    public Funcionario(String nome, String cpf, String idade, double salario) {
    }

    public Funcionario(String nome, String cpf, String idade, Long id, String cargo, boolean ativo, Departamento departamento, double salario) {
        super(nome, cpf, idade);
        this.id = id;
        this.cargo = cargo;
        this.ativo = ativo;
        this.departamento = departamento;
        this.salario = salario;
    }

    public Funcionario(String nome, String cpf, String idade, Long id, String cargo, boolean ativo, String dataAdmissao, int horasDebito, int cargaHoraria, int horasTrabalhadas, Departamento departamento, double salario) {
        super(nome, cpf, idade);
        this.id = id;
        this.cargo = cargo;
        this.ativo = ativo;
        this.dataAdmissao = dataAdmissao;
        this.horasDebito = horasDebito;
        this.cargaHoraria = cargaHoraria;
        this.horasTrabalhadas = horasTrabalhadas;
        this.departamento = departamento;
        this.salario = salario;
    }

    public String getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(String dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }

    public int getHorasDebito() {
        return horasDebito;
    }

    public void setHorasDebito(int horasDebito) {
        this.horasDebito = horasDebito;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public int getHorasTrabalhadas() {
        return horasTrabalhadas;
    }

    public void setHorasTrabalhadas(int horasTrabalhadas) {
        this.horasTrabalhadas = horasTrabalhadas;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
}
