package com.example.demo.service;

import com.example.demo.model.Departamento;
import com.example.demo.model.Funcionario;
import com.example.demo.repository.DepartamentoRepository;
import com.example.demo.repository.FuncionarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FuncionarioService {

    @Autowired
    FuncionarioRepository funcionarioRepository;

    @Autowired
    DepartamentoRepository departamentoRepository;

    public List<Funcionario> listarFuncionarios() {
        return funcionarioRepository.findAll();
    }

    public Funcionario criar(Funcionario funcionario) {
        return funcionarioRepository.save(funcionario);
    }

    public Funcionario atualizar(Long id, Funcionario funcionario) {
        Optional<Funcionario> optionalFuncionario = funcionarioRepository.findById(id);
        if (optionalFuncionario.isPresent()) {
            Funcionario funcionarioExistente = optionalFuncionario.get();
            funcionarioExistente.setNome(funcionario.getNome());
            funcionarioExistente.setCargo(funcionario.getCargo());
            funcionarioExistente.setAtivo(funcionario.isAtivo());
            return funcionarioRepository.save(funcionarioExistente);
        }
        return null;
    }

    public boolean deletar(Long id) {
        if (funcionarioRepository.existsById(id)) {
            funcionarioRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public int qtdFuncionarios() {
        return (int) funcionarioRepository.count();
    }

    public Funcionario buscarPorId(Long id) {
        return funcionarioRepository.findById(id).orElse(null);
    }

    public Funcionario promoverGerente(Long id) {
        Optional<Funcionario> optionalFuncionario = funcionarioRepository.findById(id);
        if (optionalFuncionario.isPresent()) {
            Funcionario funcionario = optionalFuncionario.get();
            funcionario.setCargo("Gerente");
            return funcionarioRepository.save(funcionario);
        }
        return null;
    }

    public ResponseEntity<String> ativarFuncionario(Long id) {
        Funcionario funcionario = funcionarioRepository.findById(id).orElse(null);
        if (funcionario == null) {
            return ResponseEntity.notFound().build();
        }
        if (funcionario.isAtivo()) {
            return ResponseEntity.badRequest().body("O funcionário já está ativo.");
        }
        funcionario.setAtivo(true);
        funcionarioRepository.save(funcionario);
        return ResponseEntity.ok("O funcionário foi ativado com sucesso.");
    }

    public ResponseEntity<String> inativarFuncionario(Long id) {
        Funcionario funcionario = funcionarioRepository.findById(id).orElse(null);
        if (funcionario == null) {
            return ResponseEntity.notFound().build();
        }
        if (!funcionario.isAtivo()) {
            return ResponseEntity.badRequest().body("O funcionário já está inativo.");
        }
        funcionario.setAtivo(false);
        funcionarioRepository.save(funcionario);
        return ResponseEntity.ok("O funcionário foi inativado com sucesso.");
    }

    public List<Funcionario> buscarPorCargo(String cargo) {
        return funcionarioRepository.findByCargo(cargo);
    }



    public Funcionario vincularDepartamento(Long idFuncionario, Long idDepartamento) {
        Funcionario funcionario = funcionarioRepository.findById(idFuncionario).orElse(null);
        Departamento departamento = departamentoRepository.findById(idDepartamento).orElse(null);

        if (funcionario != null && departamento != null) {
            funcionario.setDepartamento(departamento);
            return funcionarioRepository.save(funcionario);
        } else {
            return null;
        }
    }

    public int calcularHorasDebito(Funcionario funcionario) {
        int horasDebito = funcionario.getCargaHoraria() - funcionario.getHorasTrabalhadas();
        return Math.max(horasDebito, 0);
    }




}
