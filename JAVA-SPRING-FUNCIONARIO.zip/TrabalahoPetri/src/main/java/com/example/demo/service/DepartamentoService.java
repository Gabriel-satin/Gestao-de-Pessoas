package com.example.demo.service;

import com.example.demo.model.Departamento;
import com.example.demo.repository.DepartamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartamentoService {


    @Autowired
    private DepartamentoRepository departamentoRepository;

    public Departamento criarDepartamento(String nome) {
        Departamento departamento = new Departamento();
        departamento.setNome(nome);
        return departamentoRepository.save(departamento);
    }

    public List<Departamento> obterTodosDepartamentos() {
        return departamentoRepository.findAll();
    }

    public Departamento obterDepartamentoPorId(Long id) {
        return departamentoRepository.findById(id).orElse(null);
    }

    public Departamento atualizarDepartamento(Long id, Departamento departamento) {
        Departamento departamentoExistente = departamentoRepository.findById(id).orElse(null);
        if (departamentoExistente != null) {
            departamentoExistente.setNome(departamento.getNome());
            return departamentoRepository.save(departamentoExistente);
        }
        return null;
    }

    public boolean excluirDepartamento(Long id) {
        if (departamentoRepository.existsById(id)) {
            departamentoRepository.deleteById(id);
            return true;
        }
        return false;
    }

}
