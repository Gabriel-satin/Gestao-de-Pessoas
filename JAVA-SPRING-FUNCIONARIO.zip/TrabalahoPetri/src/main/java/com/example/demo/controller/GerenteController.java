package com.example.demo.controller;

import com.example.demo.model.Gerente;
import com.example.demo.service.GerenteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/gerentes")
public class GerenteController {

    @Autowired
    private GerenteService gerenteService;


    @PostMapping
    public ResponseEntity<Gerente> criar(@RequestBody Gerente gerente) {
        Gerente novoGerente = gerenteService.criar(gerente);
        return ResponseEntity.status(HttpStatus.CREATED).body(novoGerente);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Gerente> buscarPorId(@PathVariable Long id) {
        Optional<Gerente> optionalGerente = gerenteService.buscarPorId(id);
        return optionalGerente.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Gerente> atualizar(@PathVariable Long id, @RequestBody Gerente gerente) {
        Gerente gerenteAtualizado = gerenteService.atualizar(id, gerente);
        if (gerenteAtualizado != null) {
            return ResponseEntity.ok(gerenteAtualizado);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (gerenteService.deletar(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}

