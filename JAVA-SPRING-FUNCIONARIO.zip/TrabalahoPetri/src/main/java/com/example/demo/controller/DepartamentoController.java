package com.example.demo.controller;

import com.example.demo.model.Departamento;
import com.example.demo.service.DepartamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departamentos")
public class DepartamentoController {

    @Autowired
    private DepartamentoService departamentoService;

    @PostMapping
    public ResponseEntity<Departamento> criarDepartamento(@RequestBody Departamento departamento) {
        Departamento novoDepartamento = departamentoService.criarDepartamento(departamento.getNome());
        return ResponseEntity.status(HttpStatus.CREATED).body(novoDepartamento);
    }

    @GetMapping
    public ResponseEntity<List<Departamento>> obterTodosDepartamentos() {
        List<Departamento> departamentos = departamentoService.obterTodosDepartamentos();
        return ResponseEntity.ok(departamentos);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Departamento> obterDepartamentoPorId(@PathVariable Long id) {
        Departamento departamento = departamentoService.obterDepartamentoPorId(id);
        if (departamento != null) {
            return ResponseEntity.ok(departamento);
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @PutMapping("/{id}")
    public ResponseEntity<Departamento> atualizarDepartamento(@PathVariable Long id, @RequestBody Departamento departamento) {
        Departamento departamentoAtualizado = departamentoService.atualizarDepartamento(id, departamento);
        if (departamentoAtualizado != null) {
            return ResponseEntity.ok(departamentoAtualizado);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirDepartamento(@PathVariable Long id) {
        if (departamentoService.excluirDepartamento(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
