package com.example.demo.controller;

import com.example.demo.model.Funcionario;
import com.example.demo.service.FuncionarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/funcionarios")
public class FuncionarioController {

    @Autowired
    FuncionarioService funcionarioService;

    @GetMapping
    public List<Funcionario> listarFuncionarios() {
        return funcionarioService.listarFuncionarios();
    }

    @PostMapping
    public ResponseEntity<Funcionario> criar(@RequestBody Funcionario funcionario) {
        Funcionario novoFuncionario = funcionarioService.criar(funcionario);
        return ResponseEntity.status(HttpStatus.CREATED).body(novoFuncionario);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Funcionario> atualizar(@PathVariable Long id,@RequestBody Funcionario funcionario) {
        Funcionario funcionarioAtualizado = funcionarioService.atualizar(id, funcionario);
        if (funcionarioAtualizado != null) {
            return ResponseEntity.ok(funcionarioAtualizado);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (funcionarioService.deletar(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/qtd-funcionarios")
    public int qtdFuncionarios() {
        return funcionarioService.qtdFuncionarios();
    }

    @PutMapping("/{id}/promover-gerente")
    public ResponseEntity<Funcionario> promoverGerente(@PathVariable Long id) {
        Funcionario funcionarioPromovido = funcionarioService.promoverGerente(id);
        if (funcionarioPromovido != null) {
            return ResponseEntity.ok(funcionarioPromovido);
        }
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/{id}/ativar")
    public ResponseEntity<String> ativarFuncionario(@PathVariable Long id) {
        ResponseEntity<String> response = funcionarioService.ativarFuncionario(id);
        if (response.getStatusCode() == HttpStatus.OK) {
            return ResponseEntity.ok(response.getBody());
        } else if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.badRequest().body(response.getBody());
        }
    }


    @PutMapping("/{id}/inativar")
    public ResponseEntity<String> inativarFuncionario(@PathVariable Long id) {
        ResponseEntity<String> response = funcionarioService.inativarFuncionario(id);
        if (response.getStatusCode() == HttpStatus.OK) {
            return ResponseEntity.ok(response.getBody());
        } else if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.badRequest().body(response.getBody());
        }
    }

    @GetMapping("/cargo/{cargo}")
    public ResponseEntity<List<Funcionario>> buscarPorCargo(@PathVariable String cargo) {
        List<Funcionario> funcionarios = funcionarioService.buscarPorCargo(cargo);
        if (!funcionarios.isEmpty()) {
            return ResponseEntity.ok(funcionarios);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{idFuncionario}/departamento/{idDepartamento}")
    public ResponseEntity<Funcionario> vincularDepartamento(@PathVariable Long idFuncionario, @PathVariable Long idDepartamento) {
        Funcionario funcionario = funcionarioService.vincularDepartamento(idFuncionario, idDepartamento);
        if (funcionario != null) {
            return ResponseEntity.ok(funcionario);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/HD/{id}")
    public ResponseEntity<Funcionario> buscarPorId(@PathVariable Long id) {
        Funcionario funcionario = funcionarioService.buscarPorId(id);
        if (funcionario != null) {
            int horasTrabalhadas = funcionario.getHorasTrabalhadas();
            int cargaHoraria = funcionario.getCargaHoraria();
            int horasDebito = cargaHoraria - horasTrabalhadas;
            if (horasDebito >= 0) {
                funcionario.setHorasDebito(horasDebito); // Definir as horas de débito no objeto Funcionario
            } else {
                funcionario.setHorasDebito(0); // Definir zero se as horas de débito forem negativas
            }
            return ResponseEntity.ok(funcionario);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

}
